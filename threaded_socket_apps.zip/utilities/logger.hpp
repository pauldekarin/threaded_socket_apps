#ifndef LOGGER_HPP
#define LOGGER_HPP

#include <iostream>
#include <string>

namespace logger{
    void cout(const std::string &sender, const std::string &msg);
}

#endif